/*
 * @Author: Runope
 * @Date: 2021-05-31 17:00:04
 * @LastEditors: Runope
 * @LastEditTime: 2021-05-31 17:01:54
 * @Description: file content
 * @contact: runope@qq.com
 */

import {print, log} from "../agent/logger"

function main() {

    print("hello js ")
}

main()