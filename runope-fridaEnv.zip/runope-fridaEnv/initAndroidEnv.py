import os


if __name__ == "__main__":
    os.system('adb push agent/utils/android/libs/r0gson.dex /data/local/tmp/r0gson.dex')
    pass